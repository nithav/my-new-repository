package org.capgemini.pojo;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Account {
	
	
	
	@Id
	private int coupon_discount_id;
	
	@NotEmpty(message="* Please enter Discount/Coupon.")
	private String discount_code;
	private double discount_percentage;
	private double coupon_value;
	
	private Date creation_date;
	
	private Date expiry_date;

	public Account(){}

	public Account(int coupon_discount_id, String discount_code, double discount_percentage, double coupon_value,
			Date creation_date, Date expiry_date) {
		super();
		this.coupon_discount_id = coupon_discount_id;
		this.discount_code = discount_code;
		this.discount_percentage = discount_percentage;
		this.coupon_value = coupon_value;
		this.creation_date = creation_date;
		this.expiry_date = expiry_date;
	}

	public int getCoupon_discount_id() {
		return coupon_discount_id;
	}

	public void setCoupon_discount_id(int coupon_discount_id) {
		this.coupon_discount_id = coupon_discount_id;
	}

	public String getDiscount_code() {
		return discount_code;
	}

	public void setDiscount_code(String discount_code) {
		this.discount_code = discount_code;
	}

	public double getDiscount_percentage() {
		return discount_percentage;
	}

	public void setDiscount_percentage(double discount_percentage) {
		this.discount_percentage = discount_percentage;
	}

	public double getCoupon_value() {
		return coupon_value;
	}

	public void setCoupon_value(double coupon_value) {
		this.coupon_value = coupon_value;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	public Date getExpiry_date() {
		return expiry_date;
	}

	public void setExpiry_date(Date expiry_date) {
		this.expiry_date = expiry_date;
	}

	@Override
	public String toString() {
		return "Account [coupon_discount_id=" + coupon_discount_id + ", discount_code=" + discount_code
				+ ", discount_percentage=" + discount_percentage + ", coupon_value=" + coupon_value + ", creation_date="
				+ creation_date + ", expiry_date=" + expiry_date + "]";
	}



}