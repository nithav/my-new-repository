function isValidSearch(){
	
	var title = film.title.value;
	var date = film.releaseDate.value;
	var rating = film.rating.value;
	var actor = film.actor.value;
	var lang = film.language.value;
	
	
	if(title!="" || date!="" || rating!=0 || actor!=0 || lang!=0 )
		return true;
		
	else{
		return false;
	}
		
}
