package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class SearchFilmServlet
 */
public class SearchFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Film film = new Film();
		int actorId =0;
		int languageId = 0;
		
		String title = request.getParameter("title");
		String rating = request.getParameter("rating");
		String release_date = request.getParameter("releaseDate");
		String actor = request.getParameter("actor");
		String language = request.getParameter("language");
		
		
		if(title!="")
			film.setTitle(title);
		
		if(rating!="")
			film.setRatings(Integer.parseInt(rating));
		
		
		if(release_date!="")
			film.setReleaseYear(new Date(release_date));
		
		if(actor!="0")
			actorId = Integer.parseInt(actor);
	
		if(language !="0")
			languageId = Integer.parseInt(language);
		
		
		IFilmService filmService = new FilmServiceImpl();
		List<Film> films = filmService.searchFilm(film,actorId,languageId);
		
		PrintWriter out = response.getWriter();
		for(Film fil: films){
			out.println(fil);
		}
		
		out.println(rating);
	}

}
