package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class ListAllFilmServlet
 */
public class ListAllFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IFilmService filmService = new FilmServiceImpl();		
		List<Film> films = filmService.getAllFilm();
		
		if( films == null)
			request.getRequestDispatcher("pages/greetings.html").forward(request, response);
		
		
		else{
			
			PrintWriter out = response.getWriter();
			
			out.println("<html>");
			out.println("<head><title>Films</title></head>"
				+ "<body>"
				+ "<h2 align=center>Film Details</h2>"
				+ "<table align=center border=1>"
				+ "<tr>"
				+ "<th>filmId</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Category</th>"
				+ "<th>Rating</th>"
				+ "<th>Release Year</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Original Language</th>"
				+ "<th>Languages</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Actors</th>"
				+ "<th>Special Features</th>"
				+ "</tr>");
				
			for(Film film: films){
				out.println("<tr>");
				out.println("<td>"+film.getFilmId()+"</td>");
				out.println("<td>"+film.getTitle()+"</td>");
				out.println("<td>"+film.getDescription()+"</td>");
				out.println("<td>"+film.getCategory().getCategoryName()+"</td>");
				out.println("<td>"+film.getRatings()+"</td>");
				out.println("<td>"+film.getReleaseYear()+"</td>");
				out.println("<td>"+film.getRentalDuration()+"</td>");
				out.println("<td>"+film.getOriginalLanguage().getLanguageName()+"</td>");
				
				out.println("<td>");
				for(Language lang: film.getLanguages()){					
					out.println(lang.getLanguageName()+", ");
				}
				out.println("</td>");
				
				out.println("<td>"+film.getLength()+"</td>");
				out.println("<td>"+film.getReplacementCost()+"</td>");
				
				out.println("<td>");
				for(Actor act: film.getActors()){					
					out.println(act.getFirstName()+" "+act.getLastName()+", ");
				}
				out.println("</td>");
				
				out.println("<td>"+film.getSpecialFeatures()+"</td>");
				out.println("</tr>");
			}	
			out.println("</table></body>");
			
			out.println("</html>");		
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
