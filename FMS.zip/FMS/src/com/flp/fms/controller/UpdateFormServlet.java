package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class UpdateFormServlet
 */
public class UpdateFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String filmId = request.getParameter("filmId");
		int id = Integer.parseInt(filmId);
		
		IFilmService filmService = new FilmServiceImpl();
		Film film = filmService.searchFilm(id);
		
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<link rel='stylesheet' type='text/css' href='css/MyStyle.css'>"
				+"<script type='text/javascript' src='script/validations.js'></script>"
				+"<link rel='stylesheet' type='text/css' href='../CSS_Style/subStyle.css'>"
				+"<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
				+"<script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
				+"<script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
				+"<!-- Javascript -->"
				+" <script>"
				+" $(function() {"
				+" $( '#datepicker1' ).datepicker({"
				+"dateFormat:'dd-M-yy'"
				+"});"
				+" $( '#datepicker1' ).datepicker('show');"
				+"$( '#datepicker1' ).datepicker('setDate',new Date("+film.getReleaseYear().getTime()+"));"
				+"});"
				+" $(function() {"
				+"$( '#datepicker2' ).datepicker({"
				+" dateFormat:'dd-M-yy'"
				+"});"
				+" $( '#datepicker2' ).datepicker('show');"
				+"$( '#datepicker2' ).datepicker('setDate',new Date("+film.getRentalDuration().getTime()+"));"
				+" });"
				+"</script>"
				
				+"<title>Film Updation Form</title>"
				
				+"</head>"
				
				
				+"<body>"
				
				
				+"<form name='film' method='post' action='UpdateFilmServlet' onsubmit='return validateForm()'  >"
				+"<h3>Film Updation Form</h3>"
				+"<table>"
				+ "<tr>"
				+ "<td>"
				+ "<input type='text' name=filmId value='"+request.getParameter("filmId")+"' hidden>"
				+ "</td>"
				+ "</tr>"
				+"<tr>"
				+"<td>Title:</td>"
				+"<td><input type='text' name='filmTitle' id='title' size='20' value='"+film.getTitle()+"'></td>"
				+"<td><div id='title_div' class='errMsg'></div></td>"
				+"</tr>"
				+"<tr>"
				+"<td>Description:</td>"
				+"<td><input type='text' name='description' size='20' value='"+film.getDescription()+"'></td>"
				+"</tr>"
				);
		
		
		out.println("<tr>");
		
		out.println("<td>Category</td>");
		out.println("<td>");
				
		out.println("<select name='category'>");
		for(Category cat : filmService.getCategories()){
			
			if(film.getCategory().getCategoryId() == cat.getCategoryId())
				out.println( " <option value= " + cat.getCategoryId() + " selected>" + cat.getCategoryName() +"</option>");
			else
				out.println( " <option value= " + cat.getCategoryId() + ">" + cat.getCategoryName() +"</option>");
		}
		out.println("</select>");
		out.println("</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>Release Year:</td>");
		out.println("<td>");
		out.println("<input type='text' name='releaseYear' id='datepicker1' value='"+film.getReleaseYear()+"'>");
		out.println("<td><div id='releaseYear_div' class='errMsg'></div></td>");
		out.println("</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>Original Language:</td>");
		out.println("<td>");
		out.println("<select name='original_lang'>");
		for(Language lang: filmService.getLanguages()){
			
			if(film.getOriginalLanguage().getLanguageId() == lang.getLanguageId())
				out.println( " <option value= " + lang.getLanguageId() + " selected>" + lang.getLanguageName() +"</option>");
			else
				out.println( " <option value= " + lang.getLanguageId() + ">" + lang.getLanguageName() +"</option>");
		}
		out.println("</select>");
		out.println("</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>Language:</td>");
		out.println("<td>select all languages</td>");
		out.println("</tr><tr><td></td>");
		out.println("<td>");
		out.println("<select name='lang' multiple>");
		for(Language lang: filmService.getLanguages()){
			int flag = 0;
			
			for(Language lan : film.getLanguages()){
				
				if(lan.getLanguageId() == lang.getLanguageId()){
					
					out.println( " <option value= " + lang.getLanguageId() + " selected>" + lang.getLanguageName() +"</option>");
					flag = 1;
					break;
				}
			}
			
			if(flag!=1)
				out.println( " <option value= " + lang.getLanguageId() + ">" + lang.getLanguageName() +"</option>");
		}		
		
		out.println("<tr>");
		out.println("<td>Actors:</td>");
		out.println("<td>select all actors</td></tr>");
		out.println("<tr><td></td><td>");
		out.println("<select multiple name='actors'>");
		for(Actor act : filmService.getActors()){
			int flag = 0;
			
			for(Actor ac : film.getActors()){
				
				if(ac.getActorId() == act.getActorId()){
					
					out.println( "<option value= " + act.getActorId() + " selected>" + act.getFirstName()+" "+act.getLastName() +"</option>");
					flag = 1;
					break;
				}	
			}
			
			if(flag!=1)
				out.println( "<option value= " + act.getActorId() + ">" + act.getFirstName()+" "+act.getLastName() +"</option>");
		}
		out.println("</select>");
		out.println("</td>");
		out.println("</tr>");
		
		
		out.println("<tr>");
		out.println("<td>Rental Duration:</td>");
		out.println("<td>");
		out.println("<input type='text' name='rentalDate' id='datepicker2' value='"+film.getRentalDuration()+"'></td>");
		out.println("<td><div id='rental_div' class='errMsg'></div>");
		out.println("</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>Length:</td>");
		out.println("<td>");
		out.println("<input type='text' name='length' size='20' value='"+film.getLength()+"'></td>");
		out.println("<td><div id='length_div' class='errMsg'></div>");
		out.println("</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>Replacement Cost:</td>");
		out.println("<td>");
		out.println("<input type='text' name='cost' size='20' value='"+film.getReplacementCost()+"'></td>");
		out.println("<td><div id='cost_div' class='errMsg'></div>");
		out.println("</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>Rating:</td>");
		out.println("<td>");
		out.println("<input type='text' name='rating' size='20' value='"+film.getRatings()+"'></td>");
		out.println("<td><div id='rating_div' class='errMsg'></div>");
		out.println("</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>special features:</td>");
		out.println("<td>");
		out.println("<textarea rows='4' name='features' cols='25'>"+film.getSpecialFeatures()+"</textarea>");
		out.println("</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td></td>");
		out.println("<td>");
		out.println("<input type='submit' class='mybtn' value='update' />");
		out.println("<input type='reset' class='mybtn' value='clear' />");
		out.println("</td>");
		out.println("</tr>");
		
		out.println("</table>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
		
		
		/*PrintWriter out = response.getWriter();
		out.println(film);*/
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
