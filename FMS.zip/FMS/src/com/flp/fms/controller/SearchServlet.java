package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class SearchServlet
 */
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id = Integer.parseInt(request.getParameter("txtsearch"));
		IFilmService filmService = new FilmServiceImpl();
		
		PrintWriter out = response.getWriter();
		
		Film film = filmService.searchFilm(id);		
		
		if(film == null){
			
			out.println("<!DOCTYPE html>"
					+ "<html>"
					+ "<head>"
					+ "<meta charset='ISO-8859-1'>"
					+ "<link rel='stylesheet' type='text/css' href='../css/MyStyle.css'>"
					+ "<script type='text/javascript' src='script/validations.js'></script>"
					+ "<title>search</title>"
					+ "</head>");
			out.print("<body><h3><font color=red>Invalid Film Id!!</font></h3></body></html>");
		}
		
		else{
			
			out.println("<!DOCTYPE html>"
					+ "<html>"
					+ "<head>"
					+ "<meta charset='ISO-8859-1'>"
					+ "<link rel='stylesheet' type='text/css' href='../css/MyStyle.css'>"
					+ "<title>search</title>"
					+ "</head>"
					+ "<body>"
					+ "<h4>Search Result</h4>"
					+ "<table border=bold>"
					+ "<tr>"
					+ "<td>ID:</td>"
					+ "<td>"+film.getFilmId()+"</td></tr>"
					+ "<tr>"
					+ "<td>Title:</td>"
					+ "<td>"+film.getTitle()+"</td></tr>"
					+ "<tr>"
					+ "<td>Description:</td>"
					+ "<td>"+film.getDescription()+"</td></tr>"
					+ "<tr>"
					+ "<td>Release Date:</td>"
					+ "<td>"+film.getReleaseYear()+"</td></tr>"
					+ "<tr>"
					+ "<td>Rental Duration</td>"
					+ "<td>"+film.getRentalDuration()+"</td></tr>"
					+ "<tr>"
					+ "<td>Replacement Cost:</td>"
					+ "<td>"+film.getReplacementCost()+"</td></tr>"
					+ "<tr>"
					+ "<td>Rating:</td>"
					+ "<td>"+film.getRatings()+"</td></tr>"
					+ "<tr>"
					+ "<td>Original Language:</td>"
					+ "<td>"+film.getOriginalLanguage().getLanguageName()+"</td></tr>"
					+ "<tr>"
					+ "<td>Other languages:</td>");
			
				out.println("<td>");
				for(Language lang : film.getLanguages()){
					out.print(lang.getLanguageName()+", ");
				}
				
				out.println("</td><tr>");
				out.println("<tr><td>Actors:</td><td>");
				for(Actor act : film.getActors()){
					out.println(act.getFirstName()+" "+act.getLastName()+", ");
				}
				out.println("</td></tr>");
				
				out.println("<tr><td>Special Features:</td>");
				out.println("<td>"+film.getSpecialFeatures()+"</td></tr>");
				out.println("</table></body></html>");
		}
		
	}

}
