package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class SearchFormServlet
 */
public class SearchFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IFilmService filmService = new FilmServiceImpl();
		PrintWriter out = response.getWriter();
		
		out.println("<!DOCTYPE html>"
				+ "<html>"
				+ "<head>"
				+ "<meta charset='ISO-8859-1'>"
				+ "<script type='text/javascript' src='script/validate_search.js'></script>"
				+ "<link rel='stylesheet' type='text/css' href='css/MyStyle.css'>"
				+ "<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
				+ "<script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
				+ "<script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
				+ "<!-- Javascript -->"
				+ " <script>"
				+ " $(function() {"
				+ " $( '#datepicker1' ).datepicker({"
				+ "dateFormat:'dd-M-yy',"
				+ "changeYear:true,"
				+ "changeMonth:true"
				+ "});"				
				+ "});"
				+ "</script>"
				+ "<title>search</title>"
				+ "</head>"
				+ "<body>"
				+ "<div>"
				+ "<form method='post' action='SearchFilmServlet' name='film' onsubmit='return isValidSearch()'>"
				+ "Title: <input type='search' name='title' size='15'>");
		
		out.println("Rating: <select name='rating'>"
				+ "<option value=0>--select--</option>"
				+ "<option value=1> 1 </option>"
				+ "<option value=2> 2 </option>"
				+ "<option value=3> 3 </option>"
				+ "<option value=4> 4 </option>"
				+ "<option value=5> 5 </option></select>");
	
		
		out.println("Release Year: <input type='text' id='datepicker1' name='releaseDate' size='10'>");
		
		out.println("<br/><br/>Actor: ");
		out.println("<select name='actor'>");
		out.println("<option value=0>--select--</option>");
			for(Actor act: filmService.getActors()){
				out.println( "<option value= " + act.getActorId() + ">" + act.getFirstName() +" "+ act.getLastName() +"</option>");
			}
		out.println("</select>");
	  
		out.println("Language: ");
		out.println("<select name='language'>");
		out.println("<option value=0>--select--</option>");
			for(Language lang: filmService.getLanguages()){
				out.println( "<option value= " + lang.getLanguageId() + ">" + lang.getLanguageName() +"</option>");
			}
		out.println("</select>");
				
		out.println("<input type='submit' class='mybtn' value='search'>"
				+ "</form>"
				+ "</div>"
				+ "</body>"
				+ "</html>");
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
