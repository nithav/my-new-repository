package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class DeleteFormServlet
 */
public class DeleteFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IFilmService filmService = new FilmServiceImpl();		
		List<Film> films = filmService.getAllFilm();
		
		
		PrintWriter out = response.getWriter();
		
		out.println("<html>");
		out.println("<head>"
			+ "<link rel='stylesheet' type='text/css' href='../css/MyStyle.css'>"
			+ "<title>Films</title></head>"
			+ "<body>"
			+ "<h2 align=center>Film Details</h2>"
			+ "<table border=1>"
			+ "<tr>"
			+ "<th>Id</th>"
			+ "<th>Title</th>"
			+ "<th>Description</th>"
			+ "<th>Category</th>"
			+ "<th>Rating</th>"
			+ "<th>Release Year</th>"
			+ "<th>Original Lang</th>"
			+ "<th>Actors</th>"
			+ "<th></th>"
			+ "</tr>");
			
		for(Film film: films){
			out.println("<tr>");
			out.println("<td>"+film.getFilmId()+"</td>");
			out.println("<td>"+film.getTitle()+"</td>");
			out.println("<td>"+film.getDescription()+"</td>");
			out.println("<td>"+film.getCategory().getCategoryName()+"</td>");
			out.println("<td>"+film.getRatings()+"</td>");
			out.println("<td>"+film.getReleaseYear()+"</td>");
			out.println("<td>"+film.getOriginalLanguage().getLanguageName()+"</td>");
						
			out.println("<td>");
			for(Actor act: film.getActors()){					
				out.println(act.getFirstName()+" "+act.getLastName()+"<br/>");
			}
			out.println("</td>");
			
			out.println("<td><a href='DeleteFilmServlet?filmId="+film.getFilmId()+"'> Delete</a></td>");
			out.println("</tr>");
		}	
		out.println("</table></body>");
		
		out.println("</html>");		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
