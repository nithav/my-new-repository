package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class AddFilmServlet
 */
public class AddFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddFilmServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IFilmService filmService = new FilmServiceImpl();
		
		Film film = new Film();
		film.setTitle(request.getParameter("filmTitle"));
		
		Category cat = new Category();
		cat.setCategoryId(Integer.parseInt(request.getParameter("category")));
		film.setCategory(cat);
		
		film.setDescription(request.getParameter("description"));
		film.setLength(Integer.parseInt(request.getParameter("length")));
		
		Date releaseDate=new Date(request.getParameter("releaseYear"));
		film.setReleaseYear(releaseDate);
		
		Date rentalDate=new Date(request.getParameter("rentalDate"));
		film.setRentalDuration(rentalDate);
		
		film.setReplacementCost(Double.parseDouble(request.getParameter("cost")));
		film.setRatings(Integer.parseInt(request.getParameter("rating")));
		film.setSpecialFeatures(request.getParameter("features"));
		
		Language lang = new Language();
		lang.setLanguageId(Integer.parseInt(request.getParameter("original_lang")));
		film.setOriginalLanguage(lang);
		
		List<Language> langList = new ArrayList<>();
		String[] languages=request.getParameterValues("lang");
		
		for(String id: languages){
			Language lan = new Language();
			lan.setLanguageId(Integer.parseInt(id));
			langList.add(lan);
		}
		film.setLanguages(langList);	
		
		
		List<Actor> actorList = new ArrayList<>();
		String[] actors=request.getParameterValues("actors");
		
		for(String id: actors){
			Actor actor = new Actor();
			actor.setActorId(Integer.parseInt(id));
			actorList.add(actor);
		}
		film.setActors(actorList);	
				
		//Persist employee Object into DataBase
		filmService.addFilm(film);
		
		request.getRequestDispatcher("CreateFilmServlet").forward(request, response);
	}

}
