package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForDB implements IFilmDao {
	
	
//------------------------- LIST ENTITIES -------------------------------	
	
	
	//function to get all Languages from database
	@Override
	public List<Language> getLanguages() {
		
		List<Language> languages=new ArrayList<>();

		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
		
		String sql="select * from language order by languageName";
				
		PreparedStatement stmt;
		try {
			
				stmt = con.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();
			
				while(rs.next()){
				
					Language language = new Language();
					
					language.setLanguageId(rs.getInt(1));
					language.setLanguageName(rs.getString(2));
				
					languages.add(language);
				}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return languages;
	}
	

	
	//function to get all categories from database
	@Override
	public List<Category> getCategories() {

		List<Category> categories = new ArrayList<>();
		
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
		
		String sql="select * from category order by categoryName";
				
		PreparedStatement stmt;
		try {
			
				stmt = con.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();
			
				while(rs.next()){
				
					Category category = new Category();
				
					category.setCategoryId(rs.getInt(1));
					category.setCategoryName(rs.getString(2));
				
					categories.add(category);
				}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
				
		return categories;
	}

	
	
	//function to get all films from database
	@Override
	public List<Film> getAllFilm() {
				
		List<Film> films = new ArrayList<>();	
			
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
			
		String sql="select * from film";
					
		PreparedStatement stmt;
		try {
				
				stmt = con.prepareStatement(sql);			
				ResultSet rs = stmt.executeQuery();
				
				films = createFilmList(con, rs);
				con.close();
				
		} catch (SQLException e) {
				e.printStackTrace();
		}
			
		return films;
	}
		
	
	
	
	
//-------------------------- SAVE FILM TO DATABASE ---------------------------
	
	
	
	
	//function to save a film to database
	@Override
	public void addFilm(Film film) {
			
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
						
		String sql="insert into film(title,description,releaseYear,categoryId,originalLanguageId,rentalDuration,length,replacementCost,rating,specialFeatures) values(?,?,?,?,?,?,?,?,?,?)";
			
		PreparedStatement pst;
		try {
				
				pst = con.prepareStatement(sql);
				
				pst.setString(1, film.getTitle());
				pst.setString(2, film.getDescription());			
				pst.setDate(3, new java.sql.Date(film.getReleaseYear().getTime()));
				pst.setInt(4, film.getCategory().getCategoryId());
				pst.setInt(5,film.getOriginalLanguage().getLanguageId());
				pst.setDate(6, new java.sql.Date(film.getRentalDuration().getTime()));
				pst.setInt(7, film.getLength());
				pst.setDouble(8,film.getReplacementCost());
				pst.setInt(9, film.getRatings());
				pst.setString(10, film.getSpecialFeatures());
				
				int count=pst.executeUpdate();			
				
				//if insertion to film table is execution is successfull
				if(count>0){
					
					//getting filmId from film table
					int filmId=0;
					
					sql="select filmId from film where title='"+film.getTitle()+"'";
							
					PreparedStatement stmt = con.prepareStatement(sql);
					ResultSet rs = stmt.executeQuery();
					
					while(rs.next()){
							
						filmId = rs.getInt(1);
					}
					
					
					
					//insertion to third party table film_actors
					sql="insert into film_actors(filmId,actorId) values(?,?)";
					pst = con.prepareStatement(sql);
					
					//getting all the actors in the film
					List<Actor> actors = film.getActors();				
					for(Actor act: actors){
						pst.setInt(1, filmId );
						pst.setInt(2, act.getActorId() );
						
						count=pst.executeUpdate();
					}
					
					
					
					//insertion to third party table film_languages
					sql="insert into film_languages(filmId,languageId) values(?,?)";
					pst = con.prepareStatement(sql);
					
					//getting all the other languages
					List<Language> languages = film.getLanguages();				
					for(Language lang: languages){
						pst.setInt(1, filmId );
						pst.setInt(2, lang.getLanguageId());
						
						count=pst.executeUpdate();
					}
				}
				
				con.close();
				
		} catch (SQLException e) {
				e.printStackTrace();
		}
	}

	
	
	
	
//---------------------------- UPDATE FILM --------------------------------	
	
	
	//function to update film
	@Override
	public void updateFilm(Film film) {
		
		
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
			
		String sql="update film set"
				+ " title ='"+film.getTitle()+"'"
				+ ", description ='"+film.getDescription()+"'"
				+ ", releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'"
				+ ", categoryId ="+film.getCategory().getCategoryId()
				+ ", originalLanguageId="+film.getOriginalLanguage().getLanguageId()
				+ ", rentalDuration='"+new java.sql.Date(film.getRentalDuration().getTime())+"'"
				+ ", length="+film.getLength()
				+ ", replacementCost="+film.getReplacementCost()
				+ ", rating="+film.getRatings()
				+ ", specialFeatures='"+film.getSpecialFeatures()+"'"
				+ " where filmId="+film.getFilmId();
		
		PreparedStatement pst;
		try {
						
				pst = con.prepareStatement(sql);			
				int count=pst.executeUpdate();			
			
				//if updation of film table is successful
				if(count>0){
				
					//updation of third party tables
					
					//deleting existing values from film_actros table
					sql="delete from film_actors where filmId="+film.getFilmId();
					pst=con.prepareStatement(sql);
					count=pst.executeUpdate();
				
					//inserting new values to film_actors table
					sql="insert into film_actors(filmId,actorId) values(?,?)";
					pst = con.prepareStatement(sql);
				
					//setting the values
					List<Actor> actors = film.getActors();				
					for(Actor act: actors){
						pst.setInt(1, film.getFilmId() );
						pst.setInt(2, act.getActorId() );
					
						count=pst.executeUpdate();
					}
				
				
					//deleting exsting values from film_languages table
					sql="delete from film_languages where filmId="+film.getFilmId();
					pst=con.prepareStatement(sql);
					count=pst.executeUpdate();
				
					//inserting new values
					sql="insert into film_languages(filmId,languageId) values(?,?)";
					pst = con.prepareStatement(sql);
				
					//setting the values
					List<Language> languages = film.getLanguages();				
					for(Language lang: languages){
						pst.setInt(1, film.getFilmId() );
						pst.setInt(2, lang.getLanguageId());
					
						count=pst.executeUpdate();
					}
				}
			
				con.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	
	
	
//----------------------- SEARCH FILM FROM DATABASE -------------------------------
	
	
	
	//FUNCTION TO SEARCH FILM FROM DATABASE USING FILM_ID
	@Override
	public Film searchFilm(int filmId) {
		
		Film film = new Film();
			
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
			
		String sql = "select * from film where filmId="+filmId;
			
		try {

				PreparedStatement pst = con.prepareStatement(sql);
				ResultSet rs = pst.executeQuery();

				//calling the createFilm() function 
				for(Film fil : createFilmList(con, rs)){
					
					film = fil;
				}
				con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
			
		return film;
	}

	
	
	
	//FUNCTION TO SEARCH FILM FROM DATABASE USING MULTIPLE FIELDS
	@Override
	public List<Film> searchFilm(Film film,int actorId,int languageId) {
				
		List<Film> films = new ArrayList<>();
		int count =0;
		
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
		
		
		if (film!=null || actorId!=0 || languageId!=0) {
			
			String sql = "select distinct * from film where";
			
			if (film.getTitle() != null) {

				sql = sql + " title='" + film.getTitle() + "'";
				
				count = 1;
			}
			
			
			if (film.getRatings() > 0) {

				if (count == 1)
					sql = sql + " and rating=" + film.getRatings();
				else
					sql = sql + " rating=" + film.getRatings();

				count = 2;
			}
			
			
			if (film.getReleaseYear() != null) {

				//converting java.util date to sql.date
				Date date = new java.sql.Date(film.getReleaseYear().getTime());

				if (count == 1 || count == 2)
					sql = sql + " and releaseYear='" + date + "'";
				else
					sql = sql + " releaseYear='" + date + "'";

				count = 3;
			}
						
			
			//selection fom both the third party tables
			if (actorId != 0 && languageId != 0) {

				if (count == 1 || count == 2 || count == 3)
					sql = sql + " and film.filmId IN ( " 
										+ "SELECT a.filmId FROM film_actors a " 
										+ "WHERE a.filmId IN "
										+ "( SELECT b.filmId FROM film_languages b " 
											+ "WHERE b.languageId = "+ languageId 
											+ " UNION "
											+ "SELECT c.filmId FROM film c "
											+ "WHERE c.originalLanguageId="+languageId+") "
										+ "AND a.actorId =" + actorId +")";
				
				else
					sql = sql + " film.filmId IN ( " 
											+ "SELECT a.filmId FROM film_actors a " 
											+ "WHERE a.filmId IN"
											+ " ( SELECT b.filmId FROM film_languages b " 
												+ "WHERE b.languageId ="+ languageId 
												+ " UNION "
												+ "SELECT c.filmId FROM film c "
												+ "WHERE c.originalLanguageId="+languageId+") "
											+ "AND a.actorId ="+ actorId +")";
			}

			else if (actorId != 0 && languageId == 0) {

				if (count == 1 || count == 2 || count == 3 || count == 4)
					sql = sql + " and film.filmId IN ("
										+ "SELECT filmId FROM film_actors "
										+ "WHERE actorId=" + actorId + ")";

				else
					sql = sql + " film.filmId IN ( "
									+ "SELECT filmId FROM film_actors "
									+ "WHERE actorId=" + actorId + ")";
			}

			else if(actorId == 0 && languageId != 0) {

				if (count == 1 || count == 2 || count == 3 || count == 4)
					sql = sql + " and film.filmId IN ("
												+ " SELECT filmId FROM film_languages "
												+ "WHERE languageId=" + languageId
												+ " UNION "
												+ "SELECT c.filmId FROM film c "
												+ "WHERE c.originalLanguageId="+languageId
							+ ")";

				else
					sql = sql + " film.filmId IN ( SELECT filmId FROM film_languages "
												+ "WHERE languageId=" + languageId
												+ " UNION "
												+ "SELECT c.filmId FROM film c "
												+ "WHERE c.originalLanguageId="+languageId
							+ ")";
			}
			
	
			try {

					PreparedStatement pst = con.prepareStatement(sql);
					ResultSet rs = pst.executeQuery();

					films = createFilmList(con, rs);
					con.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
	
			return films;
		}
		
		else
			return null;
		
	}
	
	

	
//--------------------------- REMOVE FILM FROM DATABASE ---------------------
	
	
	
	//FUNCTION TO REMOVE FILM BY ID
	@Override
	public void removeFilm(int filmId) {
			
		ConnectionClass conClass = new ConnectionClass();
		Connection con = conClass.getConnection();
		
		String sql = "delete from film where filmId="+filmId;
		
		try {
			
			PreparedStatement pst = con.prepareStatement(sql);
			int count=pst.executeUpdate();	
	
			if(count>0){
				
				sql = "delete from film_actors where filmId="+filmId;
				pst = con.prepareStatement(sql);
				count = pst.executeUpdate();
				
				sql = "delete from film_languages where filmId="+filmId;
				pst = con.prepareStatement(sql);
				count = pst.executeUpdate();
			}
			
			con.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	
	
	
//---------------------- SUPPORTING FUNCTIONS ------------------------------------	
	
	
	
	//FUNCTION TO CREATE A LIST OF FILMS BY RETRIEVING DATA FROM DATABASE
	public List<Film> createFilmList(Connection con,ResultSet rs){
		
		List<Film> films = new ArrayList<>();
		
		try {
			while(rs.next()){
				
				Film film = new Film();
				
				film.setFilmId(rs.getInt(1));
				film.setTitle(rs.getString(2));
				film.setDescription(rs.getString(3));
				film.setReleaseYear(rs.getDate(4));
				
				Category cat = new Category();
				cat.setCategoryId(rs.getInt(5));
				
				//retrieving category name from category table
				String str = "select categoryName from category where categoryId="+rs.getInt(5);
				PreparedStatement pst = con.prepareStatement(str);
				ResultSet result = pst.executeQuery();
				while(result.next()){
					cat.setCategoryName(result.getString(1));
				}
				
				film.setCategory(cat);
				
				//retrieving language name from language table
				Language lang = new Language();
				lang.setLanguageId(rs.getInt(6));
				
				str = "select languageName from language where languageId="+rs.getInt(6);
				pst = con.prepareStatement(str);
				result = pst.executeQuery();
				while(result.next()){
					lang.setLanguageName(result.getString(1));
				}
				
				film.setOriginalLanguage(lang);
				
				film.setRentalDuration(rs.getDate(7));
				film.setLength(rs.getInt(8));
				film.setReplacementCost(rs.getDouble(9));
				film.setRatings(rs.getInt(10));
				film.setSpecialFeatures(rs.getString(11));
				
				
				//Adding set of languages to film				
				List<Language> languages = getAllFilmLanguages(con, film.getFilmId());
				film.setLanguages(languages);
				
				//Adding set of Actors to film
				List<Actor> actors = getAllActorsOfFilm(con, film.getFilmId());
				film.setActors(actors);
				
				films.add(film);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}	
		return films;
	}
	
	
	
	
	
	//TO GET ALL LANGUAGES IN WHICH FILM WAS RELEASED
	public List<Language> getAllFilmLanguages(Connection con,int filmId){
		List<Language> languages = new ArrayList<>();				
			
		String sql1="select languageId from film_languages where filmId="+filmId;
		PreparedStatement stmt1;
		try {
				
			stmt1 = con.prepareStatement(sql1);
			ResultSet rs1 = stmt1.executeQuery();
				
			while(rs1.next()){
					
				//retrieving language details from language table
				String sql2 = "select * from language where languageId="+rs1.getInt(1);
				PreparedStatement stmt2 = con.prepareStatement(sql2);
				ResultSet rs2 = stmt2.executeQuery();
					
				while(rs2.next()){
						
					Language lan = new Language();
					lan.setLanguageId(rs2.getInt(1));
					lan.setLanguageName(rs2.getString(2));
						
					languages.add(lan);
				}
			}
				
		} catch (SQLException e) {
				e.printStackTrace();
		}		
			
		return languages;
	}

	
		
	//TO GET ALL ACTORS IN A FILM
	public List<Actor> getAllActorsOfFilm(Connection con,int filmId){
			
		List<Actor> actors = new ArrayList<>();
			
		String sql3="select actorId from film_actors where filmId="+filmId;
		PreparedStatement stmt3;
		try {
				
			stmt3 = con.prepareStatement(sql3);			
			ResultSet rs3 = stmt3.executeQuery();
				
			while(rs3.next()){
					
				//retrieving actor details from actor table
				String sql4 = "select * from actor where actorId="+rs3.getInt(1);
				PreparedStatement stmt4 = con.prepareStatement(sql4);
				ResultSet rs4 = stmt4.executeQuery();
					
				while(rs4.next()){
						
					Actor act = new Actor();
					act.setActorId(rs4.getInt(1));
					act.setFirstName(rs4.getString(2));
					act.setLastName(rs4.getString(3));
												
					actors.add(act);					
				}
			}			
				
		} catch (SQLException e) {
			e.printStackTrace();
		}			
			
		return actors;
	}


	
}////////////////////end of class
