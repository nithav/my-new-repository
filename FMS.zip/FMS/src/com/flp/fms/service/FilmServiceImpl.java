package com.flp.fms.service;

import java.util.List;
import com.flp.fms.dao.ActorDaoImplForDB;
import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl implements IFilmService {

	private IFilmDao filmDao=new FilmDaoImplForDB();
	private IActorDao actorDao = new ActorDaoImplForDB();
	
	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

	@Override
	public List<Category> getCategories() {
		
		return filmDao.getCategories();
	}
	
	@Override
	public List<Actor> getActors() {
		
		return actorDao.getActors();
	}
	
	@Override
	public List<Film> getAllFilm() {
		
		return filmDao.getAllFilm();
	}

	
	
	@Override
	public void addFilm(Film film) {
		
		filmDao.addFilm(film);
	}
	
	
	
	@Override
	public void updateFilm(Film film) {

		filmDao.updateFilm(film);	
	}
	
	

	//FUNCTION TO SEARCH FILM FROM DATABASE USING ID
	@Override
	public Film searchFilm(int filmId) {
		
		return filmDao.searchFilm(filmId);
	}
	
	
	//FUNCTION TO SEARCH FILM FROM DATABASE USING MULTIPLE FIELDS
	@Override
	public List<Film> searchFilm(Film film,int actorId,int languageId) {
		
		return filmDao.searchFilm(film,actorId,languageId);
	}
	
	
	//REMOVING FILM USING FILM ID
	@Override
	public void removeFilm(int filmId) {
		
		filmDao.removeFilm(filmId);
	}

}
